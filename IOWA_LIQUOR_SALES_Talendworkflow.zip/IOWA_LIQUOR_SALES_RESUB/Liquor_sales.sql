/* Liquor sales: Measures */



-- Sales $
    select
        ROUND(sum([Invoice_Sale_Dollars]),2) as 'TotalSales'
    from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h;



-- Sales volume (gallons)
    select
        ROUND(sum([Invoice_Volume_Sold_Gallons]),2) as 'TotalSalesVolume (In Gallons)'
    from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h;



-- Sales volume (bottles)
    select
        ROUND(sum([Invoice_Bottles_Sold]),2) as 'TotalSalesVolume (Bottles)'
    from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h



-- Gross profit (retail price - cost)
    select ROUND(TotalRetailCost - TotalSalesCost, 2) as 'GrossProfit'
    from
    (
        select
            sum([State_Bottle_Retail] * [Bottles_Sold]) as 'TotalRetailCost',
            sum([State_Bottle_Cost] * [Bottles_Sold]) as 'TotalSalesCost'
        from    [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Lineitem] l
            join [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
                on l.[Invoice_Number] = h.[Invoice_Number]
    ) sq;